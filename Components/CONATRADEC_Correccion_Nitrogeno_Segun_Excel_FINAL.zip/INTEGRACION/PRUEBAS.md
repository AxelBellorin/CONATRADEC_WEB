# Pruebas de validación

## Caso exacto del Excel

Entradas:

```text
N total = 0.05 %
Materia orgánica = 2 %
```

Resultado convertido esperado:

```text
46.2 lb/Mz
```

## Caso para detectar la fórmula antigua

Entradas:

```text
N total = 0.20 %
Materia orgánica = 3.10 %
```

Resultado correcto:

```text
286.44 lb/Mz
```

La fórmula antigua producía aproximadamente:

```text
443.98 lb/Mz
```

## Validaciones funcionales

1. Iniciar la API y revisar que no existan errores del inicializador.
2. Abrir Unidades y conversiones.
3. Seleccionar Nitrógeno.
4. Confirmar:
   - fórmula `NITROGENO_MO_ESTANDAR`;
   - factor principal `2000000`;
   - factor secundario `0.015`;
   - factor terciario `1.54`;
   - divisor `100`.
5. Ejecutar el simulador con el caso del Excel.
6. Crear un análisis online.
7. Descargar nuevamente los datos offline.
8. Repetir el análisis sin conexión.
9. Comparar los resultados online y offline.
10. Confirmar que los PDF muestran lb/Mz.


## Persistencia de una configuración estándar

1. Iniciar la API y confirmar la migración de la fórmula antigua.
2. Cambiar temporalmente un factor desde la administración.
3. Reiniciar la API.
4. Confirmar que la fórmula estándar modificada no es sobrescrita.
5. Restaurar los valores oficiales del Excel después de la prueba.
