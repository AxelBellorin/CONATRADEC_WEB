# Corrección de nitrógeno según el Excel

Esta corrección alinea el cálculo online y offline con la hoja
`Requerimiento anual` del archivo de referencia.

## Fórmula aplicada

```text
N lb/Mz =
N total (%) × Materia orgánica (%)
× 2,000,000 kg/Ha
× 0.015
× 1.54
÷ 100
```

Equivalencias:

- masa del suelo: `2,000,000 kg/Ha`;
- mineralización tropical: `0.015`;
- conversión `kg/Ha → lb/Mz`: `2.2 × 0.7 = 1.54`;
- divisor de porcentajes: `100`.

Con el ejemplo del Excel:

```text
0.05 × 2 × 2,000,000 × 0.015 × 1.54 ÷ 100
= 46.2 lb/Mz
```

El requerimiento anual de `442.2 lb/Mz` del Excel se obtiene después:

```text
346.5 lb/Mz de base nutricional
+ 95.7 lb/Mz de extracción por producción
= 442.2 lb/Mz
```

## Archivos

Reemplazar en el backend:

```text
Infrastructure/AnalisisSueloDatabaseInitializer.cs
```

Reemplazar en la web:

```text
Components/Pages/UnidadesConversiones.razor
```

## Qué hace al iniciar la API

- crea la configuración correcta en bases nuevas;
- migra la configuración N/% de bases existentes;
- cambia la fórmula a `NITROGENO_MO_ESTANDAR`;
- aplica los factores del Excel;
- conserva los análisis históricos ya guardados;
- modifica cálculos nuevos y análisis reprocesados.

## Aplicación offline

No se modifica `MotorCalculoLocalService.cs`, porque ya soporta
`NITROGENO_MO_ESTANDAR`.

Después de publicar el backend, los dispositivos deben:

1. conectarse a internet;
2. abrir `Datos sin conexión`;
3. buscar o descargar la actualización;
4. reemplazar el paquete anterior del motor.

El hash del paquete cambia automáticamente porque la configuración de
conversiones procede de la base de datos.

## Base de datos

No requiere ejecutar un script SQL manual. La corrección se realiza de forma
idempotente durante el arranque de la API.


## Ajuste final de seguridad de la migración

La corrección de nitrógeno solo reemplaza:

- `NITROGENO_MO_LEGADO`; o
- la combinación antigua conocida:
  `1,000,000 / 0.015 / 1.54 / 100`.

Cuando la configuración ya utiliza `NITROGENO_MO_ESTANDAR`, el inicializador
no vuelve a imponer los factores del Excel. Por tanto, una modificación
administrativa posterior no se pierde al reiniciar la API.
